$(document).ready(function(){
  loadChartist = new Chartist.Pie('#timeWheel .ct-chart', activityGraph, chartistOptions);
})
